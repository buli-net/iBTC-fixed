package net.buli.ibtc
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity: AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_settings)
        val p = getSharedPreferences("ibtc", MODE_PRIVATE)
        findViewById<Button>(R.id.btnShowSeed).setOnClickListener {
            Toast.makeText(this, p.getString("mnemonic",""),1).show()
        }
        findViewById<Button>(R.id.btnBackup).setOnClickListener {
            Toast.makeText(this, "Backup: "+p.getString("mnemonic",""),1).show()
        }
        findViewById<Button>(R.id.btnAbout).setOnClickListener {
            Toast.makeText(this,"iBTC Mainnet v1.0",0).show()
        }
    }
}
