package net.buli.ibtc
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity: AppCompatActivity() {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.Main)
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        val p = getSharedPreferences("ibtc", MODE_PRIVATE)
        val addr = p.getString("address","")
        findViewById<TextView>(R.id.tvAddress).text = addr
        findViewById<Button>(R.id.btnSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<Button>(R.id.btnSend).setOnClickListener { startActivity(Intent(this, SendActivity::class.java)) }
        findViewById<Button>(R.id.btnReceive).setOnClickListener { /* show QR later */ }
        loadBalance(addr)
    }
    private fun loadBalance(addr: String?) {
        if (addr.isNullOrEmpty()) return
        scope.launch {
            val bal = withContext(Dispatchers.IO) {
                try {
                    val req = Request.Builder().url("https://blockstream.info/api/address/$addr").build()
                    val resp = client.newCall(req).execute().body?.string() ?: ""
                    val funded = Regex(""chain_stats":\{"funded_txo_sum":(\d+)").find(resp)?.groupValues?.get(1)?.toLong() ?: 0L
                    val spent = Regex(""spent_txo_sum":(\d+)").find(resp)?.groupValues?.get(1)?.toLong() ?: 0L
                    (funded - spent) / 1e8
                } catch (e: Exception) { 0.0 }
            }
            findViewById<TextView>(R.id.tvBalance).text = String.format("%.8f BTC", bal)
        }
    }
}
