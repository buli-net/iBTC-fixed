package net.buli.ibtc
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.bitcoinj.core.Coin
import org.bitcoinj.core.Address
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject

class SendActivity: AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main)
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_send)
        findViewById<Button>(R.id.btnSendNow).setOnClickListener {
            val to = findViewById<EditText>(R.id.etTo).text.toString()
            val amt = findViewById<EditText>(R.id.etAmount).text.toString().toDoubleOrNull() ?: 0.0
            if (to.isEmpty() || amt<=0) { Toast.makeText(this,"Nhập đủ",0).show(); return@setOnClickListener }
            send(to, amt)
        }
    }
    private fun send(to: String, amt: Double) {
        val p = getSharedPreferences("ibtc", MODE_PRIVATE)
        val mnemonic = p.getString("mnemonic","")!!.split(" ")
        scope.launch {
            try {
                val wallet = WalletManager.fromMnemonic(mnemonic)
                val addr = Address.fromString(WalletManager.params, to)
                val req = SendRequest.to(addr, Coin.valueOf((amt*1e8).toLong()))
                wallet.completeTx(req)
                wallet.commitTx(req.tx)
                val hex = req.tx.bitcoinSerialize().joinToString(""){"%02x".format(it)}
                withContext(Dispatchers.IO) {
                    val client = OkHttpClient()
                    val body = RequestBody.create("text/plain".toMediaType(), hex)
                    client.newCall(Request.Builder().url("https://blockstream.info/api/tx").post(body).build()).execute()
                }
                Toast.makeText(this@SendActivity,"Đã broadcast",1).show()
            } catch (e: Exception) {
                Toast.makeText(this@SendActivity,"Lỗi: "+e.message,1).show()
            }
        }
    }
}
