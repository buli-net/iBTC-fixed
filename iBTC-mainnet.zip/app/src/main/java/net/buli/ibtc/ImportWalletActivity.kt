package net.buli.ibtc
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ImportWalletActivity: AppCompatActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b) }
}
