package net.buli.ibtc
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

class LockActivity: AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_lock)
        val p = getSharedPreferences("ibtc", MODE_PRIVATE)
        if (!p.getBoolean("has_wallet", false)) {
            startActivity(Intent(this, CreateWalletActivity::class.java)); finish(); return
        }
        findViewById<Button>(R.id.btnUnlock).setOnClickListener {
            val pwd = findViewById<EditText>(R.id.etPassword).text.toString()
            val hash = MessageDigest.getInstance("SHA-256").digest(pwd.toByteArray()).joinToString(""){"%02x".format(it)}
            if (hash == p.getString("pwd_hash","")) {
                startActivity(Intent(this, MainActivity::class.java)); finish()
            } else Toast.makeText(this,"Sai mật khẩu",0).show()
        }
    }
}
