package net.buli.ibtc
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

class CreateWalletActivity: AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_create)
        findViewById<Button>(R.id.btnCreate).setOnClickListener {
            val p1 = findViewById<EditText>(R.id.etPwd1).text.toString()
            val p2 = findViewById<EditText>(R.id.etPwd2).text.toString()
            if (p1 != p2 || p1.length<6) { Toast.makeText(this,"MK không khớp",0).show(); return@setOnClickListener }
            val (wallet, mnemonic) = WalletManager.createNew()
            val hash = MessageDigest.getInstance("SHA-256").digest(p1.toByteArray()).joinToString(""){"%02x".format(it)}
            getSharedPreferences("ibtc", MODE_PRIVATE).edit()
                .putBoolean("has_wallet", true)
                .putString("pwd_hash", hash)
                .putString("mnemonic", mnemonic.joinToString(" "))
                .putString("address", wallet.currentReceiveAddress().toString())
                .apply()
            Toast.makeText(this,"Ví tạo: "+mnemonic.joinToString(" "),1).show()
            startActivity(Intent(this, MainActivity::class.java)); finish()
        }
    }
}
