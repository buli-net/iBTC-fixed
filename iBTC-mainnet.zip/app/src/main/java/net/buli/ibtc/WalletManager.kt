package net.buli.ibtc
import android.content.Context
import org.bitcoinj.core.NetworkParameters
import org.bitcoinj.params.MainNetParams
import org.bitcoinj.wallet.Wallet
import org.bitcoinj.crypto.MnemonicCode
import java.security.SecureRandom

object WalletManager {
    val params: NetworkParameters = MainNetParams.get()
    fun createNew(): Pair<Wallet, List<String>> {
        val seed = ByteArray(16); SecureRandom().nextBytes(seed)
        val mnemonic = MnemonicCode.INSTANCE.toMnemonic(seed)
        val wallet = Wallet.fromSeed(params, MnemonicCode.toSeed(mnemonic, ""))
        return wallet to mnemonic
    }
    fun fromMnemonic(words: List<String>): Wallet {
        val seed = MnemonicCode.toSeed(words, "")
        return Wallet.fromSeed(params, seed)
    }
}
